# Omini-Food-Clone
This project is a non-affiliated educational clone for personal learning and demonstration purposes. It is not linked to the original website and is intended solely for showcasing development skills and techniques.
